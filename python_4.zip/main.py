list=[20,30,40,50]
min=-999
max=-999
for i in range(0,len(list)):
    if list [i]<min:
        min=list[i]
    if list [i]>max:
        max=list[i]
print(min,max)        