class car:
    def company(self,name):
        i=['toyota','Merchades','suziki']
        if name in i:
            print("welcome to",name)
    def model(self,name):
        d={'toyota':['fortuner','innova'],
'Mercedes':['BMW'],'suziki':['swift','Alto']}
        if name in d:
            print(d[name])
    def price(self,name,m):
        print("you have selected",m)
        prices_list={'fortuner':7500000,
'Innova':5000000,'BMW':10000000,
'swift':300000,'Alto':100000}
        if m in prices_list:
            car_price=prices_list[m]
            gst=0.1*car_price
            insurance=100000
            final_price=car_price+gst+insurance
            print("Final price:",final_price)
n=input("Enter the car company:")
c=car()
c.company(n)
c.model(n)
m=input("Enter model of car:")
c.price(n,m)
            
    
    