sum1=0
sum2=0
for i in range (1,31):
    if i%6==0:
        sum1=sum1+i
    else:
        sum2=sum2+i
print(sum1-sum2)        